import React, { useState, useEffect } from 'react';
import {
  addSignalsFromRawText,
  exportSignalsJSON,
  resetToDefault,
  clearAllSignals,
  saveSignals,
  getBotConfig,
  saveBotConfig,
  SAMPLE_RAW_TEXT
} from '../services/storageService';

function getApiBaseUrl() {
  if (typeof window === 'undefined') return import.meta.env.VITE_API_URL || 'http://localhost:3001';

  const { hostname, protocol } = window.location;
  const isLocalhost = hostname === 'localhost' || hostname === '127.0.0.1';

  if (!isLocalhost) return '';

  return import.meta.env.VITE_API_URL || `${protocol}//${hostname}:3001`;
}

const API_BASE_URL = getApiBaseUrl();

// Các tin nhắn mẫu để test nhanh 1-click
const TEMPLATE_SETUP = `🚀 FINAI TRADING - TÍN HIỆU GIAO DỊCH
──────────────────────────────
🔹 Chỉ báo phát tín hiệu: 🔮 Gann FinAI
🪙 Cặp tiền: XAUUSD (Vàng)
🎯 Hướng giao dịch: 🟢 BUY (MUA)
⏱️ Khung tín hiệu: ALL (Tất cả khung thời gian (M1 ➔ D1))
⚡️ Trạng thái: KÊ LỆNH CHỜ (PENDING LIMIT - Góc Gann Retest)
⏳ Thời hạn hủy lệnh (Expiration): 5 phút
💎 Giá vào lệnh (Buy Limit): 4,578.62
🛑 Cắt lỗ (SL): 4,574.35 (-42.7 pips)
🎯 Chốt lời (TP1 1:1): 4,582.89 (+42.7 pips)
🚀 Chốt lời (TP2 1:3): 4,591.43 (+128.1 pips)
🏆 Chốt lời (TP3 1:5): 4,599.97 (+213.5 pips)
──────────────────────────────
🛡️ KỊCH BẢN VÀO LỆNH & CHIA VOLUME (1 LỆNH 100% VOL):
├ 📊 Khối lượng: Vào 100% Volume tại Entry 4,578.62
├ ⚠️ Mức rủi ro khuyến nghị: Tối đa 1% - 2% tổng tài khoản
├ 💼 Quản lý vị thế: Cắn TP1 ➔ Dời SL về BE. Cắn TP2 ➔ Dời SL lệnh 3 lên mốc TP1 để khóa 1 phần lợi nhuận.
└ ✍️ Tín hiệu hỗ trợ giao dịch - Tuân thủ tuyệt đối quy tắc quản lý vốn!
──────────────────────────────
💡 Mẫu Cấu hình: "GAN"
🤖 Hệ thống FinAI Trading - Phân tích tự động 24/7`;

const TEMPLATE_EXECUTED = `🚀 ĐÃ VÀO LỆNH THỨ #9 TRONG NGÀY (2026-08-28)
──────────────────────
📡 Chiến lược: GAN
📌 Loại lệnh: 🟢 BUY | Cặp: XAUUSD | Volume: 0.10 lot
🎯 Giá vào (Entry): 4578.62
⛔️ Stop Loss: 4574.35
🎯 Take Profit: 4582.89
⏰ Thời gian vào lệnh: 2026-08-28 11:15:07
──────────────────────
🤖 Lệnh thứ #9 đã được ghi nhận vào nhật ký ngày 2026-08-28`;

const TEMPLATE_CANCELLED = `⛔️ HỦY LỆNH (ĐÃ CHẠM TP) - BUY XAUUSD (Lệnh #9)
⚠️ Giá đã chạm TP trước khi khớp Entry. Vô hiệu hóa setup!
📌 Limit Entry: 4578.62
📊 0.0 pips (Không khớp)
⏰ Time: 2026-08-28 11:19:00`;

const TEMPLATE_SL = `🛑 SL HIT - BUY XAUUSD (Lệnh #7)
📌 Entry: 4593.99 ➔ Exit: 4584.72
📊 -92.7 pips
⏰ Time: 2026-08-28 01:28:01`;

const TEMPLATE_TP = `✅ TP HIT - BUY XAUUSD (Lệnh #4)
📌 Entry: 4604.26 ➔ Exit: 4609.38
📊 +51.2 pips
⏰ Time: 2026-08-28 05:40:38`;

export default function AdminPanel({ signals, onDataChange }) {
  const [activeTab, setActiveTab] = useState('input'); // 'input', 'table', 'json', 'bot'
  const [rawInput, setRawInput] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [filterStatus, setFilterStatus] = useState('ALL');
  
  // Bot Config State
  const [botConfig, setBotConfig] = useState(getBotConfig());
  const [isPolling, setIsPolling] = useState(false);
  const [botLogs, setBotLogs] = useState([]);

  useEffect(() => {
    const loadBackendConfig = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/api/admin/config`);
        if (!res.ok) return;

        const backendConfig = await res.json();
        setBotConfig(prev => ({ ...prev, ...backendConfig }));
        setIsPolling(Boolean(backendConfig.enableCron && backendConfig.botToken));
      } catch (err) {
        setBotLogs(prev => [
          `[${new Date().toLocaleTimeString()}] ⚠️ Chưa kết nối được backend 3001, app sẽ chỉ dùng dữ liệu local.`,
          ...prev
        ]);
      }
    };

    loadBackendConfig();
  }, []);

  const saveBotConfigToBackend = async (nextConfig) => {
    saveBotConfig(nextConfig);

    const res = await fetch(`${API_BASE_URL}/api/admin/config`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(nextConfig)
    });

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.error || `Backend HTTP ${res.status}`);
    }

    return res.json();
  };

  const showFeedback = (msg) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(''), 3500);
  };

  // Xử lý nạp tin nhắn từ ô input
  const handleParseAndSave = () => {
    if (!rawInput.trim()) {
      alert('Vui lòng dán nội dung tin nhắn Telegram vào ô!');
      return;
    }

    const added = addSignalsFromRawText(rawInput);
    if (added.length > 0) {
      showFeedback(`✅ Đã phân tích thành công và lưu ${added.length} bản ghi vào JSON!`);
      setRawInput('');
      if (onDataChange) onDataChange();
    } else {
      alert('Không nhận diện được cấu trúc tin nhắn. Vui lòng kiểm tra lại định dạng!');
    }
  };

  // Thao tác với mẫu nhanh
  const handleLoadTemplate = (tpl, autoSave = false) => {
    setRawInput(tpl);
    if (autoSave) {
      const added = addSignalsFromRawText(tpl);
      showFeedback(`⚡️ Đã nạp ngay 1 bản ghi mới vào hệ thống!`);
      if (onDataChange) onDataChange();
    }
  };

  // Xóa 1 bản ghi
  const handleDeleteRecord = (id) => {
    if (window.confirm('Bạn có chắc chắn muốn xóa bản ghi này?')) {
      const updated = signals.filter(s => s.id !== id);
      saveSignals(updated);
      showFeedback('🗑️ Đã xóa bản ghi thành công!');
      if (onDataChange) onDataChange();
    }
  };

  // Xóa tất cả
  const handleClearAll = () => {
    if (window.confirm('CẢNH BÁO: Bạn có chắc muốn xóa TOÀN BỘ dữ liệu JSON hiện tại?')) {
      clearAllSignals();
      showFeedback('🗑️ Đã làm sạch toàn bộ dữ liệu!');
      if (onDataChange) onDataChange();
    }
  };

  // Khôi phục mặc định
  const handleResetDefault = () => {
    if (window.confirm('Khôi phục danh sách dữ liệu mẫu từ tin nhắn gốc?')) {
      resetToDefault();
      showFeedback('🔄 Đã khôi phục dữ liệu mẫu thành công!');
      if (onDataChange) onDataChange();
    }
  };

  // Import JSON từ file
  const handleImportJSON = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const parsed = JSON.parse(evt.target.result);
        if (Array.isArray(parsed)) {
          saveSignals(parsed);
          showFeedback(`📥 Đã import thành công ${parsed.length} bản ghi JSON!`);
          if (onDataChange) onDataChange();
        } else {
          alert('File JSON không hợp lệ (cần là danh sách mảng Array)!');
        }
      } catch (err) {
        alert('Lỗi đọc file JSON: ' + err.message);
      }
    };
    reader.readAsText(file);
  };

  // Bật/Tắt Bot Telegram Polling
  const handleTogglePolling = async () => {
    if (isPolling) {
      try {
        const nextConfig = { ...botConfig, enableCron: false };
        await saveBotConfigToBackend(nextConfig);
        setBotConfig(nextConfig);
        setIsPolling(false);
        setBotLogs(prev => [`[${new Date().toLocaleTimeString()}] ⏹ Đã tắt engine lắng nghe Telegram trên backend.`, ...prev]);
      } catch (err) {
        setBotLogs(prev => [`[${new Date().toLocaleTimeString()}] ❌ Không tắt được backend: ${err.message}`, ...prev]);
      }
    } else {
      if (!botConfig.botToken) {
        alert('Vui lòng nhập Telegram Bot Token trước khi kích hoạt!');
        return;
      }
      try {
        const nextConfig = { ...botConfig, enableCron: true };
        await saveBotConfigToBackend(nextConfig);
        setBotConfig(nextConfig);
        setIsPolling(true);
        setBotLogs(prev => [
          `[${new Date().toLocaleTimeString()}] ▶ Đã bật engine Telegram trên backend. Khi channel/group có tin mới, SSE sẽ tự đẩy về Admin và Client.`,
          ...prev
        ]);
      } catch (err) {
        setBotLogs(prev => [`[${new Date().toLocaleTimeString()}] ❌ Không bật được backend: ${err.message}`, ...prev]);
      }
    }
  };

  // Lọc dữ liệu hiển thị
  const filteredSignals = signals.filter(s => {
    if (filterStatus === 'ALL') return true;
    if (filterStatus === 'TP') return s.status === 'TP_HIT' || (s.pips && s.pips > 0);
    if (filterStatus === 'SL') return s.status === 'SL_HIT' || (s.pips && s.pips < 0);
    if (filterStatus === 'CANCELLED') return s.status === 'CANCELLED';
    if (filterStatus === 'ACTIVE') return s.status === 'ACTIVE';
    if (filterStatus === 'PENDING') return s.status === 'PENDING';
    return true;
  });

  return (
    <div className="admin-container">
      {/* Admin Top Header */}
      <div className="admin-header">
        <div className="admin-header-left">
          <span className="admin-badge">⚡️ ADMIN CONTROL CENTER</span>
          <h1 className="admin-main-title">Quản Lý & Bóc Tách Dữ Liệu Telegram</h1>
        </div>
        <div className="admin-header-actions">
          <button className="btn-secondary" onClick={exportSignalsJSON}>
            📥 Xuất File .JSON ({signals.length})
          </button>
          <label className="btn-secondary file-upload-label">
            📤 Nhập .JSON
            <input type="file" accept=".json" onChange={handleImportJSON} style={{ display: 'none' }} />
          </label>
          <button className="btn-danger-outline" onClick={handleResetDefault}>
            🔄 Khôi phục Mẫu
          </button>
        </div>
      </div>

      {successMsg && (
        <div className="admin-alert-toast">
          {successMsg}
        </div>
      )}

      {/* Admin Navigation Tabs */}
      <div className="admin-tabs">
        <button
          className={`admin-tab-btn ${activeTab === 'input' ? 'active' : ''}`}
          onClick={() => setActiveTab('input')}
        >
          📝 Nạp Tin Nhắn & Parser
        </button>
        <button
          className={`admin-tab-btn ${activeTab === 'table' ? 'active' : ''}`}
          onClick={() => setActiveTab('table')}
        >
          📋 Danh Sách Dữ Liệu ({signals.length})
        </button>
        <button
          className={`admin-tab-btn ${activeTab === 'json' ? 'active' : ''}`}
          onClick={() => setActiveTab('json')}
        >
          🔍 Xem Raw JSON
        </button>
        <button
          className={`admin-tab-btn ${activeTab === 'bot' ? 'active' : ''}`}
          onClick={() => setActiveTab('bot')}
        >
          🤖 Cấu Hình Bot Telegram {isPolling && <span className="pulse-mini"></span>}
        </button>
      </div>

      {/* TAB 1: NẠP TIN NHẮN TELEGRAM */}
      {activeTab === 'input' && (
        <div className="admin-section-card">
          <div className="section-subtitle">
            Nhập hoặc dán tin nhắn bất kỳ từ nhóm Telegram vào đây. Hệ thống tự động bóc tách thành đối tượng JSON chuẩn và lưu trữ realtime.
          </div>

          <div className="quick-templates">
            <span className="quick-label">⚡️ Mẫu thử nhanh (1-Click Test):</span>
            <button className="btn-tpl" onClick={() => handleLoadTemplate(TEMPLATE_SETUP, true)}>
              💎 1. Tín hiệu Setup (Gann Buy Limit)
            </button>
            <button className="btn-tpl" onClick={() => handleLoadTemplate(TEMPLATE_EXECUTED, true)}>
              🚀 2. Đã vào lệnh #9
            </button>
            <button className="btn-tpl" onClick={() => handleLoadTemplate(TEMPLATE_CANCELLED, true)}>
              ⛔️ 3. Hủy lệnh #9 (Chạm TP trước)
            </button>
            <button className="btn-tpl" onClick={() => handleLoadTemplate(TEMPLATE_SL, true)}>
              🛑 4. Cắt lỗ SL Hit #7 (-92.7p)
            </button>
            <button className="btn-tpl" onClick={() => handleLoadTemplate(TEMPLATE_TP, true)}>
              ✅ 5. Chốt lời TP Hit #4 (+51.2p)
            </button>
            <button className="btn-tpl-highlight" onClick={() => handleLoadTemplate(SAMPLE_RAW_TEXT, true)}>
              📦 6. Nạp Full Bundle (5 tin nhắn cùng lúc)
            </button>
          </div>

          <div className="input-group">
            <textarea
              className="telegram-textarea"
              placeholder="Dán tin nhắn Telegram từ nhóm người khác gửi tại đây..."
              rows={8}
              value={rawInput}
              onChange={(e) => setRawInput(e.target.value)}
            />
          </div>

          <div className="input-actions">
            <button className="btn-primary-action" onClick={handleParseAndSave}>
              🚀 Phân Tích & Lưu Vào JSON Ngay
            </button>
            <button className="btn-secondary" onClick={() => setRawInput('')}>
              Làm trống ô
            </button>
          </div>
        </div>
      )}

      {/* TAB 2: BẢNG DỮ LIỆU ĐÃ LƯU */}
      {activeTab === 'table' && (
        <div className="admin-section-card">
          <div className="table-filter-bar">
            <div className="filter-group">
              <span>Lọc trạng thái:</span>
              {['ALL', 'TP', 'SL', 'CANCELLED', 'ACTIVE', 'PENDING'].map(st => (
                <button
                  key={st}
                  className={`btn-filter ${filterStatus === st ? 'active' : ''}`}
                  onClick={() => setFilterStatus(st)}
                >
                  {st}
                </button>
              ))}
            </div>

            <button className="btn-danger-sm" onClick={handleClearAll}>
              🗑 Xóa tất cả ({signals.length})
            </button>
          </div>

          <div className="table-responsive">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Thời Gian</th>
                  <th>Cặp Tiền</th>
                  <th>Loại / Lệnh</th>
                  <th>Giá Vào (Entry)</th>
                  <th>SL / TP</th>
                  <th>Pips</th>
                  <th>Trạng Thái</th>
                  <th>Thao Tác</th>
                </tr>
              </thead>
              <tbody>
                {filteredSignals.length === 0 ? (
                  <tr>
                    <td colSpan="8" style={{ textAlign: 'center', padding: '30px', color: 'var(--text-secondary)' }}>
                      Không có bản ghi nào phù hợp.
                    </td>
                  </tr>
                ) : (
                  filteredSignals.map(item => {
                    const isBuy = item.action === 'BUY';
                    const pips = parseFloat(item.pips) || 0;
                    return (
                      <tr key={item.id}>
                        <td>
                          <div style={{ fontWeight: 600 }}>{item.timeStr}</div>
                          <div style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>{item.dateStr}</div>
                        </td>
                        <td>
                          <span className="pair-tag">{item.symbol}</span>
                        </td>
                        <td>
                          <span style={{ color: isBuy ? 'var(--color-buy)' : 'var(--color-sell)', fontWeight: 700 }}>
                            {isBuy ? '🟢 BUY' : '🔴 SELL'}
                          </span>
                          {item.orderNumber && <span className="badge-ord">#{item.orderNumber}</span>}
                          <div style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>
                            {item.orderType || item.strategy || 'FinAI'}
                          </div>
                        </td>
                        <td style={{ fontFamily: 'var(--font-mono)', fontWeight: 700 }}>
                          {item.entry ? item.entry.toLocaleString() : '---'}
                          {item.exit && <div style={{ fontSize: '11px', color: '#94a3b8' }}>➔ Exit: {item.exit}</div>}
                        </td>
                        <td style={{ fontSize: '12px', fontFamily: 'var(--font-mono)' }}>
                          {item.sl && <div style={{ color: 'var(--color-sell)' }}>SL: {item.sl}</div>}
                          {item.tp1 && <div style={{ color: 'var(--color-buy)' }}>TP1: {item.tp1}</div>}
                        </td>
                        <td style={{
                          fontFamily: 'var(--font-mono)',
                          fontWeight: 800,
                          color: pips > 0 ? 'var(--color-buy)' : (pips < 0 ? 'var(--color-sell)' : 'var(--text-secondary)')
                        }}>
                          {pips > 0 ? `+${pips}p` : `${pips}p`}
                        </td>
                        <td>
                          <span className={`status-pill ${item.status?.toLowerCase()}`}>
                            {item.status}
                          </span>
                        </td>
                        <td>
                          <div className="table-actions">
                            <button className="btn-icon" title="Xem JSON" onClick={() => setSelectedRecord(item)}>
                              👁
                            </button>
                            <button className="btn-icon-danger" title="Xóa" onClick={() => handleDeleteRecord(item.id)}>
                              ✕
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: XEM RAW JSON */}
      {activeTab === 'json' && (
        <div className="admin-section-card">
          <div className="json-header">
            <h3>📦 Dữ Liệu JSON Toàn Cục (Realtime Schema)</h3>
            <button className="btn-secondary" onClick={() => {
              navigator.clipboard.writeText(JSON.stringify(signals, null, 2));
              showFeedback('📋 Đã sao chép toàn bộ JSON vào Clipboard!');
            }}>
              📋 Sao chép JSON
            </button>
          </div>
          <pre className="json-viewer">
            {JSON.stringify(signals, null, 2)}
          </pre>
        </div>
      )}

      {/* TAB 4: CẤU HÌNH BOT TELEGRAM */}
      {activeTab === 'bot' && (
        <div className="admin-section-card">
          <h3 style={{ marginBottom: '10px' }}>🤖 Kết Nối Telegram Bot API Trực Tiếp</h3>
          <p className="section-subtitle">
            Bot chỉ đọc được tin nhắn ở nơi bot được thêm vào: chat riêng với bot, group có bot, hoặc channel mà bot là admin.
          </p>

          <div className="telegram-source-guide">
            <div className="source-guide-item">
              <span className="source-guide-step">1</span>
              <div>
                <strong>Tạo bot</strong>
                <span>Lấy token từ @BotFather rồi dán vào ô bên dưới.</span>
              </div>
            </div>
            <div className="source-guide-item">
              <span className="source-guide-step">2</span>
              <div>
                <strong>Gắn bot vào nguồn tin</strong>
                <span>Với channel: thêm bot làm admin. Với group: thêm bot vào group và cho phép đọc tin nhắn.</span>
              </div>
            </div>
            <div className="source-guide-item">
              <span className="source-guide-step">3</span>
              <div>
                <strong>Gửi tin test</strong>
                <span>Bật lắng nghe rồi gửi một tin mẫu trong channel/group. Log sẽ hiện Chat ID để bạn lọc đúng nguồn.</span>
              </div>
            </div>
          </div>

          <div className="form-grid">
            <div className="form-group">
              <label>Telegram Bot Token (từ @BotFather):</label>
              <input
                type="text"
                className="admin-input"
                placeholder="123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ..."
                value={botConfig.botToken}
                onChange={(e) => setBotConfig({ ...botConfig, botToken: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label>Chu kỳ kiểm tra (ms):</label>
              <input
                type="number"
                className="admin-input"
                value={botConfig.pollInterval || 3000}
                onChange={(e) => setBotConfig({ ...botConfig, pollInterval: parseInt(e.target.value, 10) || 3000 })}
              />
            </div>
            <div className="form-group form-grid-full">
              <label>Chat ID / Channel ID cần nghe (tùy chọn):</label>
              <input
                type="text"
                className="admin-input"
                placeholder="Để trống = nghe tất cả nơi bot có mặt. Channel/group thường có dạng -100xxxxxxxxxx"
                value={botConfig.chatId || ''}
                onChange={(e) => setBotConfig({ ...botConfig, chatId: e.target.value.trim() })}
              />
            </div>
          </div>

          <div style={{ marginTop: '16px', display: 'flex', gap: '10px' }}>
            <button
              className={isPolling ? 'btn-danger-action' : 'btn-primary-action'}
              onClick={handleTogglePolling}
            >
              {isPolling ? '⏹ Dừng Lắng Nghe Telegram' : '▶ Bắt Đầu Lắng Nghe Realtime'}
            </button>
            <button className="btn-secondary" onClick={async () => {
              try {
                await saveBotConfigToBackend(botConfig);
                showFeedback('💾 Đã lưu cấu hình Bot vào backend!');
              } catch (err) {
                setBotLogs(prev => [`[${new Date().toLocaleTimeString()}] ❌ Không lưu được backend: ${err.message}`, ...prev]);
              }
            }}>
              Lưu Cấu Hình
            </button>
          </div>

          {/* Bot Logs */}
          <div className="bot-logs-box">
            <div className="logs-title">Nhật ký kết nối (Logs):</div>
            {botLogs.length === 0 ? (
              <div style={{ color: 'var(--text-secondary)', fontSize: '12px' }}>Chưa có sự kiện nào.</div>
            ) : (
              botLogs.map((log, idx) => (
                <div key={idx} className="log-line">{log}</div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Modal xem chi tiết 1 bản ghi JSON */}
      {selectedRecord && (
        <div className="modal-overlay" onClick={() => setSelectedRecord(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>🔍 Chi Tiết Bản Ghi JSON ({selectedRecord.id})</h3>
              <button className="btn-close" onClick={() => setSelectedRecord(null)}>✕</button>
            </div>
            <pre className="json-viewer" style={{ maxHeight: '400px' }}>
              {JSON.stringify(selectedRecord, null, 2)}
            </pre>
            <div style={{ marginTop: '14px', textAlign: 'right' }}>
              <button className="btn-secondary" onClick={() => setSelectedRecord(null)}>Đóng</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
